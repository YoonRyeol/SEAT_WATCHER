import cv2
import requests
import numpy as np
import datetime
import os
import time

cap = cv2.VideoCapture(1)
#frame_width = int(cap.get(3))
#frame_height = int(cap.get(4))

capture = False
isStart = False

def is_there_seat():
    origin = cv2.imread("origin.jpg", 0)
    captured = cv2.imread("30.jpg", 0)

    per = [ [0, 0 ], [ 63, 95 ]]

    spot1, spot2 = [round(origin.shape[0] * per[0][1] * 0.01), round(origin.shape[1] * per[0][0] * 0.01)], [round(origin.shape[0] * per[1][1] * 0.01), round(origin.shape[1] * per[1][0] * 0.01)]
    origin = origin[spot1[0]:spot2[0], spot1[1]:spot2[1]]
    captured = captured[spot1[0]:spot2[0], spot1[1]:spot2[1]]


#   img = cv2.imread("test_images/before.jpg", 0)
#   img2 = cv2.imread("test_images/after.jpg", 0)

    origin_result = cv2.adaptiveThreshold(origin, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 91, 5)
    captured_result = cv2.adaptiveThreshold(captured, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 91, 5)

    cnt_correct = 0
    SUM = 0

    for y in range(spot1[0], spot2[0]):
        for x in range(spot1[1], spot2[1]):
            if (origin_result.item(y, x) == captured_result.item(y, x)):
                cnt_correct += 1

    print((cnt_correct / (origin.shape[0]*origin.shape[1])) * 100)
    print((cnt_correct / ((spot2[1] - spot1[1]) * (spot2[0] - spot1[0]))) * 100)

    cv2.imshow("1", origin_result)
    cv2.imshow("2", captured_result)
    return

if os.path.isfile("origin.jpg"):
    isStart = True


while (True):
    ret, frame = cap.read()
    now = datetime.datetime.now().strftime("%S")
    now = str(now)

    if ret == True:
        # Display the resulting frame
        cv2.imshow('frame', frame)
        if not os.path.isfile("origin.jpg"):
            time.sleep(2)
            cv2.imwrite("origin.jpg", frame)

        if cv2.waitKey(1) & 0xFF == ord('o'):
            cv2.imwrite("origin.jpg", frame)
            isStart = True
        if(now == "30" and capture != True and isStart is not False) :
            cv2.imwrite(str(now)+".jpg", frame)
            is_there_seat()
            capture = True

        if(now == "31"):
            capture = False

    # Break the loop
    else:
        break
cap.release()



#   https://m.blog.naver.com/PostView.nhn?blogId=samsjang&logNo=220502203203&proxyReferer=https:%2F%2Fwww.google.com%2F
#   img = cv2.GaussianBlur(img, (5, 5), 0)
#   _, img_result3 = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
#   cv2.imshow("3_"+str(n), img_result3)

# def eqAtoB(x1, x2, y1, y2, X) :
#     if(round(((y2 - y1) / (x2 - x1)) * (X - x1) + y1) != round(((y2 - y1) / (x2 - x1)) * ((X-1) - x1) + y1)) :
#         return round(((y2 - y1) / (x2 - x1)) * (X - x1) + y1)
#
# for X in range(x[0], x[1]+1) :
#     print(X, eqAtoB(x[0], x[1], y[0], y[1], X))


#보내고자하는 파일을 'rb'(바이너리 리드)방식 열고
files = open('test_images/test_image_1.jpg', 'rb')

# 파이썬 딕셔너리 형식으로 file 설정
upload = {'file':files}
# String 포맷
obj={"name":'test_image_1.jpg'}

# request.post방식으로 파일전송.
res = requests.post('http://3.15.205.35:8000/', files = upload, data = obj)


cv2.waitKey(0)
cv2.destroyAllWindows()